package rule3Examples;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;

public class Example1 {
	//16, 28, 40, 51, 62
	public static void main(String args[]) {

	}

	public String f() {
		Optional<String> str = Optional.empty();

		//line 16
		if(!str.isPresent()) {
			return "illes";
		} else {
			return str.get();
		}
	}

	public int f1() {
		OptionalInt myInt = OptionalInt.empty();

		//line 28
		if(myInt.isPresent()) {
			return myInt.getAsInt();
		} else {
			return 1;
		}
	}

	public long f2() {
		OptionalLong myLong = OptionalLong.empty();

		//line 40
		if(myLong.isPresent()) {
			return myLong.getAsLong();
		} else {
			return 1;
		}
	}

	public double f3() {
		OptionalDouble myLong = OptionalDouble.empty();

		//line 51
		if(myLong.isPresent()) {
			return myLong.getAsDouble();
		} else {
			return 1;
		}
	}

	public String f4() {
		Optional<String> str = Optional.empty();

		//line 62
		if(str.isPresent()) {
			for(int i=0; i < 10; i++) {
				return str.get();
			}
		} else {
			for(int i=0; i < 10; i++) {
				return "illes";
			}
		}
		
		return "";
	}
}
