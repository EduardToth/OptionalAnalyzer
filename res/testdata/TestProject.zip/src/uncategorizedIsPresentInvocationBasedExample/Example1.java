package uncategorizedIsPresentInvocationBasedExample;

import java.util.Optional;
import java.util.stream.Stream;

public class Example1 {

	void f() {

		Optional<String> opt = Optional.empty();
		//12
		if(opt.isPresent()) {
			return;
		}
		
		//line 17
		if(opt.isPresent()) {
			System.out.println();
		}
		
		if(opt.isPresent()) {
			System.out.println(opt.get());
		}

		//line26
		Stream.of("1", "2", "3", "4")
		.findAny()
		.isPresent();
	}

	String f1() {
		Optional<String> opt = Optional.empty();

		if(opt.isPresent()) {
			return opt.get();
		} else {
			throw new IndexOutOfBoundsException();
		}
	}
}
