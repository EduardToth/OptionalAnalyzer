package rule26Examples;
import java.util.*;
public class Example1 {

	void f() {
		Optional<String> str = null;
		OptionalInt i = null;
		OptionalDouble d = null;
		OptionalLong l = null;
		
		boolean b;
		b = !str.isPresent();
		b = !i.isPresent();
		b = !d.isPresent();
		b = !l.isPresent();
	}
}
