package rule25Examples;
import java.util.*;
public class Example1 {
	//8, 11, 15, 19
	void f() {
		Optional<String> str1 = null, str2 = null;
		
		if(str1 == str2);
		
		OptionalInt i1 = null, i2 = null;
		if(i1 == i2);
		
		OptionalDouble d1 = null, d2 = null;
		
		if(d1 == d2);
		
		OptionalLong l1 = null, l2 = null;
		
		if(l1 == l2);
	}
}
