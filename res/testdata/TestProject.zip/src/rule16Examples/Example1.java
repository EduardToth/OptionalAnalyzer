package rule16Examples;

import java.util.*;
//9, 11, 13, 15, 17
public class Example1 {

	int nr;
	
	void f(OptionalInt nr) {}
	
	void f(OptionalDouble nr) {}
	
	void f(OptionalLong nr) {}
	
	void f(Optional<String> str) {}
	
	void f(int x, Optional<String> str) {}
	
	void setNr(OptionalInt nr) {}
}
