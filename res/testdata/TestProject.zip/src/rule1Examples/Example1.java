package rule1Examples;
//valid
import java.util.*;
//problems should appear at lines: 9, 15, 21, 26
public class Example1 {
	
	public void f1() {
		//line 9
		Optional<String> str = null;
	}
	
	
	public void f2() {
		//line 15
		OptionalInt myInt = null;
	}
	
	
	public void f3() {
		//line 21
		OptionalDouble myFloat = null;
	}
	
	public void f4() {
		//line 26
		OptionalLong myLong = null;
	}
}
