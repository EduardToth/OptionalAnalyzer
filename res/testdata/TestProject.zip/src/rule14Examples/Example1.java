package rule14Examples;

import java.util.*;
//6, 7, 8, 9
public class Example1 {
	public Example1(Optional<String> str) {}
	public Example1(String str, OptionalInt myInt) {}
	public Example1(Optional<String> str, OptionalDouble d) {}
	public Example1(OptionalLong myLong) {}
}
