package rule4Examples;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;

public class Example1 {
	//18, 29, 40, 51, 62, 78
	public static void main(String args[]) {

	}

	public String f() {
		Optional<String> str = Optional.empty();

		//line 18
		if(str.isPresent()) {
			return str.get();
		} else {
			return g();
		}
	}

	public int f1() {
		OptionalInt myInt = OptionalInt.empty();

		//line 29
		if(myInt.isPresent()) {
			return myInt.getAsInt();
		} else {
			return g1();
		}
	}

	public long f2() {
		OptionalLong myLong = OptionalLong.empty();

		//line 40
		if(myLong.isPresent()) {
			return myLong.getAsLong();
		} else {
			return g2();
		}
	}

	public double f3() {
		OptionalDouble myLong = OptionalDouble.empty();

		//line 51
		if(myLong.isPresent()) {
			return myLong.getAsDouble();
		} else {
			return g3();
		}
	}

	public String f4() {
		Optional<String> str = Optional.empty();

		//line 62
		if(str.isPresent()) {
			for(int i=0; i < 10; i++) {
				return str.get();
			}
		} else {
			for(int i=0; i < 10; i++) {
				return g();
			}
		}

		return "";
	}
	
	public String f5() {
		//line 78
		Optional<String> str = Optional.empty();
		return str.orElse(g());
	}
	
	String g() {
		return "illes";
	}
	
	int g1() {
		return 1;
	}
	
	long g2() {
		return (long)1;
	}
	
	double g3() {
		return 1.2;
	}
}
