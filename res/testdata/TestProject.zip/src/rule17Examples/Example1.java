package rule17Examples;

import java.util.*;
//7, 13, 17
public class Example1 {

	Optional<List<?>> f() {
		List l = null;
		
		return Optional.ofNullable(l);
	}
	
	Optional<Integer[]> f1() {
		return null;
	}
	
	Optional<Map<Integer[], String>> f2() {
		return null;
	}
}
