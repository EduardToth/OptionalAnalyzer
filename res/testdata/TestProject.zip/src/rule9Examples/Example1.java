package rule9Examples;

import java.io.OptionalDataException;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;
//15, 79
public class Example1 {
		
	
	void f() {
		Optional<String> str = Optional.empty();
		//line 15
		if(str.isPresent()) {
			System.out.println();
		} else {
			System.out.println(str.get());
		}
	}
	
	void f1() {
		OptionalInt optionalInt = OptionalInt.empty();
		
		if(optionalInt.isPresent()) {
			int nr = 0;
			nr++;
			System.out.println();
			for(;;) {
				break;
			}
			System.out.println(optionalInt.getAsInt());
		} else {
			while( true ) {
				break;
			}
			System.out.println("valami");
		}
	}
	
	void f2() {
		OptionalDouble optionalD = OptionalDouble.empty();
		String str = "illes";
		
		if(optionalD.isPresent()) {
			str.chars();
			System.out.println(optionalD.getAsDouble());
		} else {
			str.indexOf(0);
		}
	}
	
	void f3() {
		OptionalDouble optionalD = OptionalDouble.empty();
		String str = "illes";
		if(optionalD.isPresent()) {
			str = "eduard";
			str.chars();
			System.out.println(optionalD.getAsDouble());
		} else {
			str.indexOf(0);
		}
	}
	
	void f4() {
		OptionalLong optionalLong = OptionalLong.empty();
		
		if(optionalLong.isPresent()) {
			optionalLong.getAsLong();
		} else {
			System.out.println();
			optionalLong.getAsLong();
		}
	}
	
	void f5() {
		OptionalLong optionalLong = OptionalLong.empty();
		//line 79
		if(!optionalLong.isPresent()) {
			System.out.println();
		} else {
			optionalLong.getAsLong();
		}
	}
	
}
