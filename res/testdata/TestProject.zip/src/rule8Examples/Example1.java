package rule8Examples;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;
//12, 22, 31, 41
public class Example1 {
	//line 12
	void f() {
		Optional<String> str = Optional.empty();
		if(str.isPresent()) {
			int nr = 0;
			nr++;
			System.out.println(str.get());
		}
	}
	//line 22
	void f1() {
		OptionalInt optionalInt = OptionalInt.empty();

		if(optionalInt.isPresent()) {
			do {
				System.out.println(optionalInt.getAsInt());
			} while( true );
		}
	}
	//line 31
	void f2() {
		OptionalLong optionalLong = OptionalLong.empty();
		if(optionalLong.isPresent()) {
			int nr = 0;
			++nr;
			System.out.println(optionalLong.getAsLong());
		}
	}

	void f3() {
		OptionalDouble optionalDouble = OptionalDouble.empty();
		//line 41
		if(optionalDouble.isPresent()) {
			for(int i=0; i < 10; i++) {
				int nr =0;
				System.out.println(optionalDouble.getAsDouble());
				++nr;
			}

		}
	}
}
