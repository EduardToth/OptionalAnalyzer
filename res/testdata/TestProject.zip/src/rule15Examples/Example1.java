package rule15Examples;
import java.util.*;

//12, 16, 20, 24
public class Example1 {

	String str;
	int nr;
	OptionalDouble d;
	OptionalLong l;
	
	public void setStr(Optional<String> str) {
		this.str = str.orElse("naspaa");
	}
	
	public void setNr(OptionalInt nr) {
		this.nr = nr.orElse(20);
	}
	
	public void setD(OptionalDouble d) {
		this.d = d;
	}
	
	public void setL(OptionalLong l) {
		this.l = l;
	}
	
	
}
