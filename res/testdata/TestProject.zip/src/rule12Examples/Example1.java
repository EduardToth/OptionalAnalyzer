package rule12Examples;

import java.util.Optional;
//10, 17, 22
public class Example1 {

	void f() {
		String str = "illes";

		String str2 = Optional.ofNullable(str).orElse("naspaa");

	}

	String f1() {
		String str = "illes";

		return Optional.ofNullable(str).orElse("naspaa");
	}
	
	int f2() {
		Integer nr = 10;
		return Optional.ofNullable(nr).orElse(20);
	}
}
