package rule7Examples;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;
//60, 47, 38, 28, 18
public class Example1 {

	String h(String str) { return "";}
	void g(String str) {}
	void g1(Integer i) {}
	void g2(Double d) {}
	void g3(Long l) {}
	void f() {
		Optional<String> str = Optional.empty();
		//line 18
		if(str.isPresent()) {
			g(str.get());
		} else {
			g(h("illes"));
		}
	}

	void f1() {
		Optional<String> str = Optional.empty();
		//line 28
		if(str.isPresent()) {
			g(h(str.get()));
		} else {
			g(h(null));
		}
	}

	void f2() {
		OptionalInt myInt = OptionalInt.empty();
		//line 38
		if(myInt.isPresent()) {
			g1(myInt.getAsInt());
		} else {
			g1(12 + 1);
		}
	}

	void f3() {
		OptionalDouble optionalDouble = OptionalDouble.empty();
		//line 48
		if(optionalDouble.isPresent()) {
			for(;;)
				g2(optionalDouble.getAsDouble());
		} else {
			for(;;)
				g2(1.2);
		}
	}
	
	void f4() {
		OptionalLong optionalLong = OptionalLong.empty();
		//line 60
		if(!optionalLong.isPresent()) {
			g3((long)2);
		} else {
			g3((optionalLong.getAsLong()));
		}
	}
}
