package rule10Examples;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;
//12, 16, 20, 24
public class Example1 {

	Optional<String> f() {
		Optional<String> str1 = Optional.empty();
		Optional<String> str2 = Optional.empty();
		//line 14
		if(str1.isPresent()) {
			return str1;
		} else {
			return str2;
		}
	}
	
	OptionalInt f1() {
		OptionalInt nr1 = OptionalInt.empty();
		OptionalInt nr2 = OptionalInt.empty();
		//line 25
		if(nr1.isPresent()) {
			return nr1;
		} else {
			return nr2;
		}
	}
	
	OptionalLong f2() {
		OptionalLong l1 = OptionalLong.empty();
		OptionalLong l2 = OptionalLong.empty();
		//line 36
		if(l1.isPresent()) {
			return l1;
		} else {
			return l2;
		}
	}
	
	OptionalDouble f3() {
		OptionalDouble d1 = OptionalDouble.empty();
		OptionalDouble d2 = OptionalDouble.empty();
		//line 47
		if(d1.isPresent()) {
			return d1;
		} else {
			return d2;
		}
	}
	
	Optional<String> f4() {
		Optional<String> status = Optional.empty();
		
		return status.orElseGet(() -> Optional<String>.of("illes"));
	}
	
	
}
