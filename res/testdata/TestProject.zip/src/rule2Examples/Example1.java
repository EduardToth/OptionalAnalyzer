package rule2Examples;

import java.util.*;
//errors should appear at 11, 18, 26, 33
public class Example1 {

	
	public void f1() {
		Optional<String> str = Optional.empty();
		//line 11
		str.get();
	}
	
	public void f2() {
		//line 18
		OptionalInt myInt = OptionalInt.empty();

		myInt.getAsInt();
	}
	
	
	public void f3() {
		//line 26
		OptionalDouble myFloat = OptionalDouble.empty();
		
		myFloat.getAsDouble();
	}
	
	public void f4() {
		//line 33
		OptionalLong myLong = OptionalLong.empty();
		
		myLong.getAsLong();
	}
	
	public void f5() {
		Optional<String> str = Optional.empty();
		if(true)
		while(true) {
			for(;;str.isPresent()) {
				str.get();
			}
		}
	}
}
