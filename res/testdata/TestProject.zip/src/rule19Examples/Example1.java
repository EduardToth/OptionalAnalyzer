package rule19Examples;

import java.util.Optional;
import java.util.OptionalInt;
//12, 13, 14, 15
public class Example1 {

	void f() {
		Integer nr = 0;
		Double d = 1.2;
		String str = "";
		Optional.ofNullable("Illes");
		Optional.of(str);
		OptionalInt.of(nr);
		h().of(str);
		
	}
	
	Optional<Object> h() {
		return Optional.ofNullable(new Object());
	}
}
