package rule13Examples;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;
//10, 11, 12, 13
public class Example1 {
	
	Optional<String> str1, str2;
	OptionalInt nr1, nr2;
	OptionalDouble d;
	OptionalLong c;
}
