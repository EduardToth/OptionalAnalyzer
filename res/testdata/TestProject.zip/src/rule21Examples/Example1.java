package rule21Examples;

import java.util.*;
//10, 11
public class Example1 {

	void f() {
		Optional<String> str1 = null, str2 = null;
		Optional<Object> o1 = null, o2 = null;
		str1.get().equals(str2.get());
		o1.get().equals(o2.get());
		o1.get().equals(o2);
		
	}
}
