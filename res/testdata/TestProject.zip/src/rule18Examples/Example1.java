package rule18Examples;
import java.util.*;

class A<T> {
	
}

public class Example1 {

	List<OptionalInt> l;
	ArrayList<Optional<String>> str;
	Map<Integer, List<Optional<String>>> m;
	A<List<Optional>> a;
	Set<Optional<String>> s;
}
