package rule6Examples;
//valid
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.OptionalLong;




//18, 29, 40, 51
public class Example1 {
	public String f() {
		Optional<String> str = Optional.empty();

		//line 18
		if(str.isPresent()) {
			return str.get();
		} else {
			throw new IndexOutOfBoundsException();
		}
	}

	public int f1() {
		OptionalInt myInt = OptionalInt.empty();

		//line 29
		if(!myInt.isPresent()) {
			throw new IndexOutOfBoundsException();
		} else {
			return myInt.getAsInt();
		}
	}

	public long f2() {
		OptionalLong myLong = OptionalLong.empty();

		//line 40
		if(myLong.isPresent()) {
			return myLong.getAsLong();
		} else {
			throw new IndexOutOfBoundsException();
		}
	}

	public double f3() {
		OptionalDouble myLong = OptionalDouble.empty();

		//line 51
		if(myLong.isPresent()) {
			return myLong.getAsDouble();
		} else {
			throw new IndexOutOfBoundsException();
		}
	}

	public String f4() {
		Optional<String> str = Optional.empty();


		if(str.isPresent()) {
			for(int i=0; i < 10; i++) {
				return str.get();
			}
		} else {
			for(int i=0; i < 10; i++) {
				throw new IndexOutOfBoundsException();
			}
		}

		return "";
	}
}
