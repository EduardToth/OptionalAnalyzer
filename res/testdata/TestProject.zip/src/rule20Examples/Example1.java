package rule20Examples;

import java.util.*;
//7, 8, 9
public class Example1 {
	
	Optional<Integer> i;
	Optional<Double> d;
	Optional<Long> l;

}
